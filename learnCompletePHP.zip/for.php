<?php
$arrCity=array("Delhi","Agra","Pune");
for($i=0;$i<count($arrCity);$i++){
	echo $arrCity[$i];
	echo "<br/>";
}
?>