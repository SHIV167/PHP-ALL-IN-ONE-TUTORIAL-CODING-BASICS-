<?php
define('NUM',10);
define('NUM',20);
echo NUM;
?>