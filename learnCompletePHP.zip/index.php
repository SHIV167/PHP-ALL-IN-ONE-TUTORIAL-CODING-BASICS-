<?php
//$name="Vishal";
//$name="Amit";
//echo $name;

$x='Vishal';
var_dump($x);
echo "<br>";

$x=10;
var_dump($x);
echo "<br>";

$x=10.10;
var_dump($x);
echo "<br>";

$x=true;
var_dump($x);
echo "<br>";
?>