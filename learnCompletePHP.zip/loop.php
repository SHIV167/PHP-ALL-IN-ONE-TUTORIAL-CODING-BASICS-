<?php
/*
for($i=1;$i<=10;$i++){
	echo 2*$i;
	echo "<br/>";
}
*/

/*$i=1;
while($i<=10){
	echo 2*$i;
	echo "<br/>";
	$i++;
}*/

$i=1;
do{
	echo 2*$i;
	echo "<br/>";
	$i++;
}while($i<=10)
?>