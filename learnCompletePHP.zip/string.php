<?php
$name="hi hello I m Vishal";
//echo 'Hello my name is $name';
//echo strlen($name);
//echo str_word_count($name);
//echo strpos($name,"I");
//echo ucfirst($name);
//echo ucwords($name);
//echo strtoupper($name);
//echo strtolower($name);
$fname="Vishal";
$lname="Gupta";
echo $fname.' '.$lname;
?>