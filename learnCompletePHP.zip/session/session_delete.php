<?php
session_start();
//unset($_SESSION['x']);
session_destroy();
?>