<?php
$number=60;
if($number>60){
	echo "First";
}elseif($number>=45 && $number<=60){
	echo "Second";
}else{
	echo "Third";
}
?>