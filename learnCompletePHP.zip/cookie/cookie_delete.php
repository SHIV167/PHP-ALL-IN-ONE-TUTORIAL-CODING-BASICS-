<?php
setcookie('city','Delhi',100);
?>