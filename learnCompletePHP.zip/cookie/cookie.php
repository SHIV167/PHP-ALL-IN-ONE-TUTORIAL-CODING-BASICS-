<?php
setcookie('city','Delhi',time()+100);
?>