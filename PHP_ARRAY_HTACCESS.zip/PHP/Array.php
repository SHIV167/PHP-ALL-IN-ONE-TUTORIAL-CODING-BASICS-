<?php   
//Single Array  
//$arr=array('shiv','jha');

//Associative Array
//$arr=array('Name'=>'shiv','Age'=>'20');
//echo '<pre>';
//print_r ($arr);

?>





<select>
<?php 
//Drop Down Array  
$arr=array('BIHAR','UP','DELHI');

foreach($arr as $arrayList){
	echo '<option>Select State</option>';
	echo '<option>'.$arrayList.'</option>';
	
}

?>
</select>


<?php   
//Nested Loop Array  
$arr=array(
array("S.NO.",'Name','City'),
array("1",'shiv','delhi'),
array("2",'rahul','patna'),
);
echo '<pre>';
print_r($arr);

?>

<table border="1" cellspacing="5" cellpadding="5">

<?php 
foreach($arr as $arrayList)
{
echo '<tr>';

	
	foreach($arrayList as $arrayDetails){
	
	
	echo '<td>'.$arrayDetails.'</td>';
	
	
	
	}
	echo '</tr>';
}




?>



</table>



